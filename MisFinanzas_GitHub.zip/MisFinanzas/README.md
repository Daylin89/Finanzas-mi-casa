# Mis Finanzas — Android v1.1

App personal de ingresos y gastos en pesos cubanos (CUP). Funciona sin internet; los datos se guardan solo en
el teléfono (archivo privado de la app). Inicio con lo que queda del mes, gastos por categoría, límites,
pagos fijos, reportes de 6 meses, exportar a Excel (CSV), copia de seguridad y PIN de entrada.
Se compila con GitHub Actions (.github/workflows/compilar-apk.yml): sube este zip al repositorio.
v1.1: 🐷 Ahorros (metas con alcancía, meta de ahorro al mes, guardar y sacar); categoría Hijos sin escuela.
