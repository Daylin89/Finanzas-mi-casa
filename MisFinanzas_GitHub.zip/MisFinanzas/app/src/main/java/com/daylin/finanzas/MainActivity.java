package com.daylin.finanzas;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;

/** Mis Finanzas: app personal sin internet. Los datos viven solo en este teléfono (archivo privado de la app). */
public class MainActivity extends Activity {
    static final int REQ_FILE = 51;
    WebView web;
    ValueCallback<Uri[]> fileCb;

    File dataFile() { return new File(getFilesDir(), "finanzas.json"); }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#F4F7F6"));
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setSupportZoom(false);
        web.addJavascriptInterface(new Bridge(), "FinApp");
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, String url) { return !url.startsWith("file:"); } // sin internet: no sale a ningún sitio
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (fileCb != null) fileCb.onReceiveValue(null);
                fileCb = cb;
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                try { startActivityForResult(Intent.createChooser(i, "Elegir copia de seguridad"), REQ_FILE); }
                catch (Exception e) { fileCb = null; return false; }
                return true;
            }
        });
        if (b != null) web.restoreState(b); else web.loadUrl("file:///android_asset/fin.html");
    }

    @Override
    protected void onSaveInstanceState(Bundle out) { super.onSaveInstanceState(out); web.saveState(out); }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_FILE && fileCb != null) {
            Uri u = res == RESULT_OK && data != null ? data.getData() : null;
            fileCb.onReceiveValue(u == null ? null : new Uri[]{u});
            fileCb = null;
        }
    }

    @Override
    public void onBackPressed() {
        web.evaluateJavascript("window.onAndroidBack && window.onAndroidBack()", v -> { if (!"true".equals(v)) MainActivity.super.onBackPressed(); });
    }

    void toast(String m) { Toast.makeText(this, m, Toast.LENGTH_LONG).show(); }

    class Bridge {
        @JavascriptInterface
        public String load() {
            try {
                File f = dataFile();
                if (!f.exists()) return "";
                byte[] d = new byte[(int) f.length()];
                try (FileInputStream in = new FileInputStream(f)) { int o = 0; while (o < d.length) { int n = in.read(d, o, d.length - o); if (n < 0) break; o += n; } }
                return new String(d, StandardCharsets.UTF_8);
            } catch (Exception e) { return ""; }
        }

        /** Guarda primero en un archivo temporal y luego lo cambia: nunca queda a medias. */
        @JavascriptInterface
        public void save(String json) {
            try {
                File tmp = new File(getFilesDir(), "finanzas.tmp");
                try (FileOutputStream o = new FileOutputStream(tmp)) { o.write(json.getBytes(StandardCharsets.UTF_8)); o.getFD().sync(); }
                if (!tmp.renameTo(dataFile())) { dataFile().delete(); tmp.renameTo(dataFile()); }
            } catch (Exception e) { runOnUiThread(() -> toast("No se pudo guardar: " + e.getMessage())); }
        }

        /** Copia de seguridad / Excel → Descargas → Mis Finanzas. */
        @JavascriptInterface
        public void saveFile(String b64, String mime, String name) {
            runOnUiThread(() -> {
                try {
                    byte[] data = android.util.Base64.decode(b64, android.util.Base64.DEFAULT);
                    Uri u;
                    if (Build.VERSION.SDK_INT >= 29) {
                        ContentValues cv = new ContentValues();
                        cv.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
                        cv.put(MediaStore.MediaColumns.MIME_TYPE, mime);
                        cv.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Mis Finanzas");
                        u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
                        if (u == null) throw new Exception("sin espacio");
                        try (java.io.OutputStream os = getContentResolver().openOutputStream(u)) { os.write(data); }
                    } else {
                        if (checkSelfPermission("android.permission.WRITE_EXTERNAL_STORAGE") != PackageManager.PERMISSION_GRANTED) {
                            requestPermissions(new String[]{"android.permission.WRITE_EXTERNAL_STORAGE"}, 9);
                            toast("Acepta el permiso y vuelve a intentarlo");
                            return;
                        }
                        File dir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "Mis Finanzas");
                        dir.mkdirs();
                        File f = new File(dir, name);
                        try (FileOutputStream fo = new FileOutputStream(f)) { fo.write(data); }
                        android.os.StrictMode.setVmPolicy(new android.os.StrictMode.VmPolicy.Builder().build());
                        u = Uri.fromFile(f);
                    }
                    final Uri fu = u;
                    new android.app.AlertDialog.Builder(MainActivity.this).setTitle("Guardado ✅")
                            .setMessage("Está en Descargas → Mis Finanzas:\n" + name)
                            .setPositiveButton("Compartir", (d, w) -> {
                                Intent i = new Intent(Intent.ACTION_SEND);
                                i.setType(mime);
                                i.putExtra(Intent.EXTRA_STREAM, fu);
                                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                                try { startActivity(Intent.createChooser(i, "Enviar " + name)); } catch (Exception e) { toast("No se pudo compartir"); }
                            })
                            .setNegativeButton("OK", null).show();
                } catch (Exception e) { toast("No se pudo guardar: " + e.getMessage()); }
            });
        }
    }
}
